cd /home/repo
git clone https://git.pluie.org/pluie/lib-yaml.git
cd lib-yaml
./build.sh
