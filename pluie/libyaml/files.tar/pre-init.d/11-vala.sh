# cd /lib-yaml/samples
# valac -v --pkg gee-0.8 --pkg pluie-echo-0.2 --pkg pluie-yaml-0.4 yaml-imports.vala
cd /lib-yaml/
./build.sh
