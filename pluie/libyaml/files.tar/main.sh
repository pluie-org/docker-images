#!/bin/bash
# @app      pluie/libyaml
# @author   a-Sansara https://git.pluie.org/pluie/docker-images

. /scripts/common.sh

cd /home/repo/lib-yaml
echo "try any samples"
bash

