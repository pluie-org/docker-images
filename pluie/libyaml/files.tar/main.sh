#!/bin/bash
# @app      pluie/libecho
# @author   a-Sansara https://git.pluie.org/pluie/docker-images

. /scripts/common.sh

initTitle "Vala shared lib pluie-yaml-0.4" "Sample"
cd /lib-yaml/bin/
./yaml-imports
bash
