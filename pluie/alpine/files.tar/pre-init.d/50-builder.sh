#!/bin/bash
# pluie/docker-images - a-Sansara (https://github.com/a-sansara)

echo -e "\ncontainer builded by \033[1;38;5;209mpluie.org\033[m - \033[1;38;5;32mhttps://git.pluie.org/pluie/docker-images\033[m\n"
