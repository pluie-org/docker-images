#!/bin/bash
# pluie/docker-images - a-Sansara (https://github.com/a-sansara)

# ls -la /scripts
chown -R root:root /scripts/
