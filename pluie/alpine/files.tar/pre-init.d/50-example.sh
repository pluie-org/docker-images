#!/bin/bash

# ls -la /scripts
chown -R root:root /scripts/
