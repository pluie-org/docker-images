#!/bin/bash
# pluie/docker-images - a-Sansara (https://github.com/a-sansara)

rm -f /var/cache/apk/*
