#!/bin/bash

rm -f /var/cache/apk/*
