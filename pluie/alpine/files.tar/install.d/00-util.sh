#!/bin/bash

apk --update add nano curl
