#!/bin/bash
# @app      pluie/ubuntu
# @author   a-Sansara https://git.pluie.org/pluie/docker-images

. /scripts/util.sh
preInit "/scripts/install.d"
