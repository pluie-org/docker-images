#!/bin/bash
# @app      pluie/ubuntu
# @author   a-Sansara https://git.pluie.org/pluie/docker-images

echo -e "\ncontainer builded by \033[1;38;5;209mpluie.org\033[m - \033[1;38;5;32mhttps://git.pluie.org/pluie/docker-images\033[m\n"
