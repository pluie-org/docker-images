chown -R root:root /scripts/
rm -f /scripts/pre-init.d/50-example.sh
