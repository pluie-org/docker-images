#!/bin/bash
# pluie/docker-images - a-Sansara (https://github.com/a-sansara)

chown -R root:root /scripts/
rm -f /scripts/pre-init.d/50-example.sh
