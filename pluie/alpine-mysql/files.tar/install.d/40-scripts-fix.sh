#!/bin/bash
# @app      pluie/alpine-mysql
# @author   a-Sansara https://git.pluie.org/pluie/docker-images

mv /scripts/dbdump.sh /dbdump
mv /scripts/dbcreate.sh /dbcreate
mv /scripts/dbload.sh /dbload
