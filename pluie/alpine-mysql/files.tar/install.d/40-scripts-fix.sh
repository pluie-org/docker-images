mv /scripts/dbdump.sh /dbdump
mv /scripts/dbcreate.sh /dbcreate
mv /scripts/dbload.sh /dbload
