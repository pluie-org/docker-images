#!/bin/bash
# pluie/docker-images - a-Sansara (https://github.com/a-sansara)

apk --update add mysql mysql-client pwgen \
