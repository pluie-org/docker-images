sleep 5
echo "running"
cat /tmp/initdb.sql
/usr/bin/mysql --user=root < /tmp/initdb.sql
rm /tmp/initdb.sql
