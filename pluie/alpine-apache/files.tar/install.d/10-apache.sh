#!/bin/bash
# pluie/docker-images - a-Sansara (https://github.com/a-sansara)

apk --update add apache2 \
php-apache2 php-cli php-phar php-zlib php-zip php-ctype php-mysqli php-pdo_mysql php-xml \
php-opcache php-pdo php-json php-curl php-gd php-mcrypt php-openssl  \
# php-pdo_odbc php-soap php-pgsql
