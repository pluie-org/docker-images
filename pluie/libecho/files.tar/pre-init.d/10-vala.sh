cd /libpluie-echo
valac --pkg pluie-echo-0.1  main.vala -o echo \
