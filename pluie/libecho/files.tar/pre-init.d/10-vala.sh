cd /libpluie-echo/samples
valac --pkg pluie-echo-0.2 pluie-outputFormatter.vala  \
