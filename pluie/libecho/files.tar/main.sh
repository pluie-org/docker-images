#!/bin/bash
# @app      pluie/libecho
# @author   a-Sansara https://git.pluie.org/pluie/docker-images

. /scripts/common.sh

initTitle "Vala shared lib pluie-echo-0.1" "Sample"
/libpluie-echo/echo
