#!/bin/bash
# @app      pluie/alpine-apache-php7
# @author   a-Sansara https://git.pluie.org/pluie/docker-images

#~ echo "http://dl-cdn.alpinelinux.org/alpine/edge/community
#~ http://dl-cdn.alpinelinux.org/alpine/edge/main
#~ http://dl-cdn.alpinelinux.org/alpine/edge/testing
#~ echo "http://alpine.gliderlabs.com/alpine/edge/community
#~ http://alpine.gliderlabs.com/alpine/edge/main
#~ http://alpine.gliderlabs.com/alpine/edge/testing
#~ " >> /etc/apk/repositories
echo "http://dl-5.alpinelinux.org/alpine/edge/community
http://dl-5.alpinelinux.org/alpine/edge/main
http://dl-5.alpinelinux.org/alpine/edge/testing
" > /etc/apk/repositories
